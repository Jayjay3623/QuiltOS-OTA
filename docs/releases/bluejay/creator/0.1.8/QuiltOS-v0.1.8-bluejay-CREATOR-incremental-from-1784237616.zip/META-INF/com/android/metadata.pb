"�
ota-property-files�payload_metadata.bin:5093:251958,payload.bin:5093:1907085,payload_properties.txt:1912236:153,apex_info.pb:2600:1774,care_map.pb:4421:625,metadata:69:760,metadata.pb:897:1655                  "�
ota-streaming-property-files�payload.bin:5093:1907085,payload_properties.txt:1912236:153,apex_info.pb:2600:1774,care_map.pb:4421:625,metadata:69:760,metadata.pb:897:1655                    *�
bluejayDgoogle/bluejay/bluejay:16/BP4A.251205.006/14401865:user/release-keys
1784237616:d
productbluejayDgoogle/bluejay/bluejay:16/BP4A.251205.006/14401865:user/release-keys"
1784237616:c
systemgenericDgoogle/bluejay/bluejay:16/BP4A.251205.006/14401865:user/release-keys"
1784237616:g

system_extbluejayDgoogle/bluejay/bluejay:16/BP4A.251205.006/14401865:user/release-keys"
1784237616:c
vendorbluejayDgoogle/bluejay/bluejay:16/BP4A.251205.006/14401865:user/release-keys"
1784192087:h
vendor_dlkmbluejayDgoogle/bluejay/bluejay:16/BP4A.251205.006/14401865:user/release-keys"
17842376162�
bluejayDgoogle/bluejay/bluejay:16/BP4A.251205.006/14401865:user/release-keys
1784324782 ����*362
2026-06-01:d
productbluejayDgoogle/bluejay/bluejay:16/BP4A.251205.006/14401865:user/release-keys"
1784324782:c
systemgenericDgoogle/bluejay/bluejay:16/BP4A.251205.006/14401865:user/release-keys"
1784324782:g

system_extbluejayDgoogle/bluejay/bluejay:16/BP4A.251205.006/14401865:user/release-keys"
1784324782:c
vendorbluejayDgoogle/bluejay/bluejay:16/BP4A.251205.006/14401865:user/release-keys"
1784192087:h
vendor_dlkmbluejayDgoogle/bluejay/bluejay:16/BP4A.251205.006/14401865:user/release-keys"
1784324782