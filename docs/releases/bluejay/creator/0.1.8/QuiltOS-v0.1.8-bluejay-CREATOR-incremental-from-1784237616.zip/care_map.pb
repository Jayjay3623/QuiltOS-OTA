
y
product
2,0,939114ro.product.build.fingerprint"Dgoogle/bluejay/bluejay:16/BP4A.251205.006/14401865:user/release-keys
w
system
2,0,278378ro.system.build.fingerprint"Dgoogle/bluejay/bluejay:16/BP4A.251205.006/14401865:user/release-keys


system_ext
2,0,143464ro.system_ext.build.fingerprint"Dgoogle/bluejay/bluejay:16/BP4A.251205.006/14401865:user/release-keys
w
vendor
2,0,150509ro.vendor.build.fingerprint"Dgoogle/bluejay/bluejay:16/BP4A.251205.006/14401865:user/release-keys
�
vendor_dlkm	2,0,12884 ro.vendor_dlkm.build.fingerprint"Dgoogle/bluejay/bluejay:16/BP4A.251205.006/14401865:user/release-keys